﻿using System.Globalization;

namespace Entidades
{
    public class Serie
    {
        private string genero;
        private string nombre;

        public Serie(string nombre, string genero)
        {
            this.nombre = nombre;
            this.genero = genero;
        }

        public Serie()
        {

        }

        public string Genero { get => genero; set => genero = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public override string ToString()
        {
            return $"{nombre} - {genero}";
        }
    }
}
