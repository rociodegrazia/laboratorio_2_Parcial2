﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class AccesoDatos
    {

        private static SqlConnection sqlConnection;
        private static SqlCommand sqlCommand;

        static AccesoDatos()
        {
            sqlConnection = new SqlConnection("Server=.;Database=20240701-SP;Trusted_Connection=True");
            sqlCommand = new SqlCommand
            {
                Connection = sqlConnection
            };
        }

        public static List<Serie> ObtenerBacklog()
        {
            List<Serie> backlog = new List<Serie>();

            try
            {
                sqlConnection.Open();
                sqlCommand.CommandText = "SELECT nombre, genero, alumno FROM dbo.series";
                using (SqlDataReader reader = sqlCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Serie serie = new Serie
                        {
                            Nombre = reader["nombre"].ToString(),
                            Genero = reader["genero"].ToString(),
                        };
                        backlog.Add(serie);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new BackLogException("Error al obtener el backlog de series.", ex);
            }
            finally
            {
                sqlConnection.Close();
            }

            return backlog;
        }


        public static void ActualizarSerie(Serie serie)
        {
            try
            {
                sqlConnection.Open();
                sqlCommand.CommandText = "UPDATE dbo.series SET alumno = @alumno WHERE nombre = @nombre";
                sqlCommand.Parameters.Clear();
                sqlCommand.Parameters.AddWithValue("@alumno", "Rocio De Grazia");
                sqlCommand.Parameters.AddWithValue("@nombre", serie.Nombre);
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new BackLogException("Error al actualizar la serie.", ex);
            }
            finally
            {
                sqlConnection.Close();
            }
        }
    }
}