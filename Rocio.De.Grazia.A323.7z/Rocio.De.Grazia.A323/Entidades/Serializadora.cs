﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
using System.Text.Json;

namespace Entidades
{
    public class Serializadora : IGuardar<List<Serie>>
    {
        public void Guardar(List<Serie> items, string ruta)
        {
            try
            {
                SerializarXML(items, ruta);
            }
            catch (Exception ex)
            {
                throw new BackLogException("Error al serializar en formato XML", ex);
            }

            try
            {
                ((IGuardar<List<Serie>>)this).Guardar(items, ruta);
            }
            catch (Exception ex)
            {
                throw new BackLogException("Error al serializar en formato JSON", ex);
            }
        }

        void IGuardar<List<Serie>>.Guardar(List<Serie> items, string ruta)
        {
            SerializarJSON(items, ruta);
        }

        private void SerializarXML(List<Serie> items, string ruta)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Serie>));
            using (TextWriter writer = new StreamWriter(ruta + ".xml"))
            {
                serializer.Serialize(writer, items);
            }
        }

        private void SerializarJSON(List<Serie> items, string ruta)
        {
            string json = JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(ruta + ".json", json);
        }
    }
}
