﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ManejadorBackLog
    {
        public event Action<Serie> SerieParaVer;
        public void IniciarManejador(List<Serie> series)
        {
            Task.Run(() => MoverSeries(series));
        }

        private void MoverSeries(List<Serie> series)
        {
            while (series.Count > 0)
            {
                int indiceAleatorio = series.GenerarRandom();
                AccesoDatos.ActualizarSerie(series[indiceAleatorio]);
                Thread.Sleep(1500);

                Serie serieParaVer = series[indiceAleatorio];
                series.RemoveAt(indiceAleatorio);

                SerieParaVer?.Invoke(serieParaVer);
            }
        }
    }
}
