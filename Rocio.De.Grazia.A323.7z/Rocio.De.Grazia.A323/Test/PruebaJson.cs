using Entidades;

namespace Test
{
    [TestClass]
    public class PruebaJson
    {
        [TestMethod]
        public void SerializarJSON_DadaListaDeSeries_SerializaAFormatoJSON()
        {
            // Arrange
            var series = new List<Serie>
            {
                new Serie { Id = 1, Nombre = "Breaking Bad", Genero = "Drama" },
                new Serie { Id = 2, Nombre = "Stranger Things", Genero = "Sci-Fi" }
            };
            var ruta = "test_series";

            // Act
            var serializadora = new Serializadora();
            ((IGuardar<List<Serie>>)serializadora).Guardar(series, ruta);

            // Assert
            Assert.True(File.Exists(ruta + ".json"));
        }

        [Hecho]
        public void BackLogException_DebeLanzarExcepcion()
        {
            // Arrange
            var mensaje = "Error en el backlog";

            // Act & Assert
            Assert.Throws<BackLogException>(() => throw new BackLogException(mensaje));
        }
    }
}