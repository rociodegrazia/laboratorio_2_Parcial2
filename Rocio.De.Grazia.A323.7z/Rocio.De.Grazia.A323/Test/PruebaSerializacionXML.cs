using Entidades;
namespace Test
{
    [TestClass]
    public class PruebaSerializacionXML
    {
        [TestMethod]
        public void SerializarXML_DadaListaDeSeries_SerializaAFormatoXML()
        {
            //Arrange 
            var series = new List<Serie>
            {
                new Serie { Id = 1, Nombre = "Breaking Bad", Genero = "Drama" },
                new Serie { Id = 2, Nombre = "Stranger Things", Genero = "Sci-Fi" }
            };
            var ruta = "test_series";

            // Act
            var serializadora = new Serializadora();
            serializadora.Guardar(series, ruta);

            // Assert
            Assert.True(File.Exists(ruta + ".xml"));

        }
    }
}