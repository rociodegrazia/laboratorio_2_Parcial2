using Entidades;
using Newtonsoft.Json;

namespace Tests
{
    [TestClass]
    public class PruebasExcepcion
    {
        [TestMethod]
        public void PruebaBackLogException()
        {
            // Arrange
            string mensajeError = "Error en el backlog";
            var excepcionInterna = new SystemException("Excepci�n interna");

            // Act
            BackLogException excepcion = new BackLogException(mensajeError, excepcionInterna);

            // Assert
            Assert.AreEqual(mensajeError, excepcion.Message);
            Assert.AreEqual(excepcionInterna, excepcion.InnerException);
        }
    }
}